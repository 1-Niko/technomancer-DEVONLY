If you want to enable dragonslayer, you just need to change the .txt to a .json file.

Keep in mind, they are *very* unfinished and almost everything is subject to change.